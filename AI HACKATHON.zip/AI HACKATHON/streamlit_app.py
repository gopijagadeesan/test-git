import streamlit as st
from app.llm import get_llm
from app.embeddings import get_embedding_model
from app.document_loader import load_and_prepare_docs
from app.vector_store import build_vector_store
from app.agent import create_ai_agent

@st.cache_resource
def setup_agent():
    files = [
        "data/faq.txt",
        "data/product_descriptions.txt",
        "data/return_policies.txt",
        "data/store_info.txt"
    ]
    documents = load_and_prepare_docs(files)
    embeddings = get_embedding_model()
    vector_store = build_vector_store(documents, embeddings)
    llm = get_llm()
    agent = create_ai_agent(vector_store, llm)
    return agent

def main():
    st.title("🛍️ Retail AI Assistant")
    st.write("Ask any question about products, returns, or store policies.")

    agent = setup_agent()

    user_input = st.text_input("Your question:", placeholder="e.g., What is your return policy for electronics?")

    if user_input:
        with st.spinner("Thinking..."):
            try:
                result = agent.invoke(user_input)
                answer = result.get("result") if isinstance(result, dict) else result
                st.success(answer)
            except Exception as e:
                st.error(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    main()
