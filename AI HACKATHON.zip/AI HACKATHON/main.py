from app.llm import get_llm
from app.embeddings import get_embedding_model
from app.document_loader import load_and_prepare_docs
from app.vector_store import build_vector_store
from app.agent import create_ai_agent
from app.cli import start_cli

def main():
    files = [
        "data/faq.txt",
        "data/product_descriptions.txt",
        "data/return_policies.txt",
        "data/store_info.txt"
    ]

    documents = load_and_prepare_docs(files)
    embeddings = get_embedding_model()
    vector_store = build_vector_store(documents, embeddings)
    llm = get_llm()
    agent = create_ai_agent(vector_store, llm)

    start_cli(agent)

if __name__ == "__main__":
    main()
