import os
import httpx

# Tiktoken cache path
TIKTOKEN_CACHE_DIR = os.path.abspath("tiktoken_cache")
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR

assert os.path.exists(os.path.join(TIKTOKEN_CACHE_DIR, "9b5ad71b2ce5302211f9c61530b329a4922fc6a4")), \
    "Tiktoken cache file is missing!"

# Internal endpoints
LLM_BASE_URL = "https://genailab.tcs.in"
LLM_MODEL = "azure/genailab-maas-gpt-4o"
LLM_API_KEY = "sk-Z5hxJ8Ee6JGtqhyeXh2_qQ"

EMBEDDING_MODEL = "azure/genailab-maas-text-embedding-3-large"
EMBEDDING_API_KEY = "sk-N209dbkUn55mryNORI87tg"

# HTTP client with SSL verification disabled (internal use only)
HTTP_CLIENT = httpx.Client(verify=False)
ASYNC_CLIENT = httpx.AsyncClient(verify=False)
