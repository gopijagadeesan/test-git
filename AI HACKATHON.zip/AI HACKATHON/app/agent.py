from langchain.chains import RetrievalQA

def create_ai_agent(vector_store, llm):
    return RetrievalQA.from_chain_type(
        llm=llm,
        retriever=vector_store.as_retriever(),
        return_source_documents=True
    )
