from langchain_openai import OpenAIEmbeddings
from .config import LLM_BASE_URL, EMBEDDING_MODEL, EMBEDDING_API_KEY, HTTP_CLIENT

def get_embedding_model():
    return OpenAIEmbeddings(
        base_url=LLM_BASE_URL,
        model=EMBEDDING_MODEL,
        api_key=EMBEDDING_API_KEY,
        http_client=HTTP_CLIENT
    )
