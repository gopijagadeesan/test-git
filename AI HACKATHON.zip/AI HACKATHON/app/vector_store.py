from langchain_community.vectorstores import FAISS

def build_vector_store(documents, embedding_model):
    return FAISS.from_documents(documents, embedding_model)
