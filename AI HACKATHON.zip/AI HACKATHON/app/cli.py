def start_cli(agent):
    print("Retail AI Assistant — ask your questions below (type 'exit' to quit):")

    while True:
        try:
            question = input("\nYour question: ").strip()
            if question.lower() in ["exit", "quit"]:
                print("Goodbye!")
                break

            result = agent.invoke(question)
            answer = result.get("result") if isinstance(result, dict) else result
            print(f"\nAnswer: {answer}")
        except KeyboardInterrupt:
            print("\nInterrupted by user.")
            break
        except Exception as e:
            print(f"\n[ERROR] {str(e)}")
