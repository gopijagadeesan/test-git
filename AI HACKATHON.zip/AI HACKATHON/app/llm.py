from langchain_openai import ChatOpenAI
from .config import LLM_BASE_URL, LLM_MODEL, LLM_API_KEY, HTTP_CLIENT

def get_llm():
    return ChatOpenAI(
        base_url=LLM_BASE_URL,
        model=LLM_MODEL,
        api_key=LLM_API_KEY,
        http_client=HTTP_CLIENT
    )
