from langchain.text_splitter import CharacterTextSplitter
from langchain_community.document_loaders import TextLoader

def load_and_prepare_docs(file_paths):
    docs = []
    for path in file_paths:
        loader = TextLoader(path)
        documents = loader.load()
        docs.extend(documents)

    splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    split_docs = splitter.split_documents(docs)
    return split_docs
